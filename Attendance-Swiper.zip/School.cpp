#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>
#include "School.h"
#include "AttendanceRecord.h"

using namespace std;

void School::addStudents(string filename) {
  ifstream ifs(filename);
  if (!ifs.is_open()) {
    cout << "Unable to open file: " << filename;
	cout<<"\n";
    return;
  }
  while (!ifs.eof()) {
    string line;
    getline(ifs, line);
    istringstream ss(line);
    string uin;
    getline(ss, uin, ',');
    string name;
    getline(ss, name);
    if (!ss.fail()) {
      this->students.push_back(Student(uin, name));
    }
  }
}
void School::addAttendanceData(std::string filename)
{
  ifstream ifs(filename);
  if (!ifs.is_open())
  {
    cout << "Unable to open file: " << filename; 
	cout<< '\n';
    return;
  }
   string line;
  getline(ifs, line);
  while (!ifs.eof())
	  {
	string id_Student;
	string idCourse;
	string month;
    string date;
	string year;

    istringstream ss(line);

    getline(ss,year,'-');
    getline(ss,month,'-');
    getline(ss,date,' ');
      
    string hour;
    string min;
    string second;
    getline(ss,hour,':');
    getline(ss,min,':');
    getline(ss,second,',');
    Date time(stoi(year),stoi(month),stoi(date),stoi(hour),stoi(min),stoi(second));
    
    
    getline(ss, idCourse, ',');

    getline(ss, id_Student);

    if (!ss.fail()) 
	{
      for(int k = 0; k < courses.size(); ++k)
	  {
        if(idCourse == courses.at(k).getID())
		{
          if((time <= courses.at(k).getEndTime()) and (time >= courses.at(k).getStartTime()))
		  {
            courses.at(k).addAttendanceRecord(AttendanceRecord(idCourse,id_Student,time));
          }
          else
		  {
            cout <<"did not save this record.";
			cout<<"\n";
          }
        }
      }
    }
  line = "";
  getline(ifs, line);
  }
  ifs.close();
}




void School::addCourses(std::string filename){
  ifstream ifs(filename);
  if (!ifs.is_open()) {
    cout << "Unable to open file: " << filename << '\n';
    return;
  }
    string line;
    getline(ifs, line);

    while ("" != line) {
		
	  string name;
      istringstream ss(line);
	  string hour;
      string min;
      string idCourse;
      getline(ss, idCourse, ',');
      getline(ss,hour,':');
      getline(ss,min,',');
      Date startTime(stoi(hour),stoi(min),0);
	  min = "";
      hour = "";

      getline(ss,hour,':');
      getline(ss,min,',');

      Date endTime(stoi(hour),stoi(min),0);

	  
      getline(ss, name);
	  
      if (!ss.fail()) {
		  
        this->courses.push_back(Course(idCourse, name,startTime,endTime));
      }
	  
      line = "";
	  
      getline(ifs, line);
  }
  ifs.close();
}


void School::listStudents()
{
  int m;
  if(0 == students.size())
  {
    cout <<"No Students";
	cout<<"\n";
  }
  for(m = 0; m < students.size(); ++m)
  {
    cout <<students.at(m).get_id();
	
	cout <<"," <<students.at(m).get_name();
	
	cout<<"\n";
  }
}


void School::listCourses()
{
	int p;
//Checks if there are no courses
  if(0 == courses.size())
  {
    cout <<"No Courses";
	cout<<"\n";
  }
  for(p = 0; p < courses.size(); ++p)
  {
    Date startTime = courses.at(p).getStartTime();
	
    Date endTime = courses.at(p).getEndTime();
	
    cout <<courses.at(p).getID() <<"," << setw(2) << setfill('0') <<startTime.getHour()<<":";
	cout<< setw(2) << setfill('0') <<startTime.getMin()<<","<< setw(2) << setfill('0') <<endTime.getHour()<<":";
	cout<< setw(2) << setfill('0') <<endTime.getMin() <<",";
	cout<<courses.at(p).getTitle();
	cout<<"\n";
  }
  
}



void School::outputStudentAttendance(std::string idStudent, std::string idCourse)
{
	
  bool check = false;
  for(int i = 0; i < courses.size(); ++i)
  {
    if((courses.at(i).getID()) == (idCourse))
	{
      for(int j = 0; j < students.size(); ++j)
	  {
        if(students.at(j).get_id() == idStudent)
		{
			
          courses.at(i).outputAttendance(idStudent);
          check = true;
		  
          break;
        }
      }
    }
  }
  if(false == check)
  {
	  
  cout <<"No Records";
  
  cout<<"\n";
  
  }
  
}


void School::outputCourseAttendance(std::string idCourse)
{
	int b;
  for(b = 0; b < courses.size(); ++b)
	  {
    if(idCourse == courses.at(b).getID()) 
	{
      courses.at(b).outputAttendance();
    }
  }
}

