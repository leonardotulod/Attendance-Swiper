#include <ctime>
#include <string>
#include <iomanip>
#include <sstream>
#include <iomanip>
#include "Date.h"

using namespace std;

Date::Date(int year, int month, int day, int hour, int min, int sec) :
    year(year), month(month), day(day), hour(hour), min(min), sec(sec) {}
    
Date::Date(int hour, int min, int sec) 
  : timestamp(0), year(0), month(0), day(0), 
    hour(hour), min(min), sec(sec) {}

string Date::getDate() {
  stringstream ss;
  ss << month << "/" << day << "/" << year << " ";
  ss << setw(2) << setfill('0') << hour << ":"; 
  ss << setw(2) << setfill('0') << min << ":";
  ss << setw(2) << setfill('0') << sec;
  return ss.str();
}


//the function below takes into account if they are equal so the > is not needed
bool Date::operator>=(Date d) 
{

  if (d.hour < this->hour) 
  {
	  
    return true;
	
  }
  
  if ((d.hour == this->hour) and (d.min < this->min))
	  {
	  
    return true;
	
  }
  if ((d.min == this->min) and (d.sec < this->sec))
	  {
	  
    return true;
	
  }
  if (d.sec == this->sec) 
	{
	  
    return true;
	
  }

  return false;
}



//the function below takes into account if they are equal so the < is not needed
bool Date::operator<=(Date d) 
{

  if (d.hour > this->hour) {
	  
    return true;
  }
  if ((d.hour == this->hour) and (d.min > this->min)) 
  {
	  
    return true;
	
  }
  
  if ((d.min == this->min) and (d.sec > this->sec)) 
  {
	  
    return true;
	
  }
  if (d.sec == this->sec) {
	  
    return true;
	
  }
    
  return false;
  
}
  

