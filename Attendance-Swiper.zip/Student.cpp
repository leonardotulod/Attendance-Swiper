#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <fstream>
#include "Student.h"

using namespace std;

Student::Student(string idStudent, string studentName)
{
    this->name = studentName;
	this->id = idStudent;
}

string Student::get_name()
{
    return this->name;
}


string Student::get_id()
{
    return this->id;
}
 
void Student::listCourses()
{
	int z; 
	
    cout <<"Courses for "<<get_id();
	
	cout<<"\n";
    for(z = 0; z < course_ids.size(); ++z)
	{
        cout <<course_ids.at(z);
		cout<<"\n";
    }
	
} 

void Student::addCourse(std::string idCourse){
	
    this->course_ids.push_back(idCourse);
	
}

