#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "Course.h"
#include "Date.h"
#include "AttendanceRecord.h"

using namespace std;

Course::Course(std::string id, std::string title, Date startTime, Date endTime): id(id), title(title), startTime(startTime), endTime(endTime)
 {
	this->endTime=endTime;
	this->startTime=startTime;
	this->title=title;
	this->id=id;
}
Date Course::getEndTime()
{
    return this->endTime;
}

Date Course::getStartTime()
{
    return this->startTime;
}

std::string Course::getTitle()
{
    return this->title;
}

std::string Course::getID()
{
    return this->id;
}

void Course::addAttendanceRecord(AttendanceRecord aRecord)
{
    this->attendanceRecords.push_back(aRecord);
}

void Course::outputAttendance()
{
	int i;
    if(0 == attendanceRecords.size())
	{
        cout <<"No Records"; 
		cout<<'\n';    
    }
    for(i = 0; i < this->attendanceRecords.size(); ++i)
		
	{
        AttendanceRecord temp = attendanceRecords.at(i);
        Date date = temp.getDate();
        cout <<date.getMonth() <<"/"; 
		cout<<date.getDay() <<"/"; 
		cout<<date.getYear()<<" ";
		cout<< setw(2) << setfill('0') <<date.getHour();
		cout<<":" << setw(2) << setfill('0') <<date.getMin();
		cout<<":"  << setw(2) << setfill('0') << date.getSec(); 
		cout<<"," <<temp.getCourseID() << "," <<temp.getStudentID() <<'\n';
    }
}

void Course::outputAttendance(std::string student_id)
{
	int j;
	
	bool check = false;
	
    for(j = 0; j < this->attendanceRecords.size(); ++j)
	{
        AttendanceRecord temp = attendanceRecords.at(j);
        if(student_id == temp.getStudentID()) {
            Date date = temp.getDate();
            check = true;
            cout <<date.getMonth(); 
			cout<<"/" <<date.getDay(); 
			cout<<"/" <<date.getYear();
			cout<<" " << setw(2) << setfill('0') <<date.getHour();
			cout<<":" << setw(2) << setfill('0') <<date.getMin();
			cout<<":"  << setw(2) << setfill('0'); 
			cout<< date.getSec() <<","; 
			cout<<temp.getCourseID(); 
			cout<< "," <<temp.getStudentID();
			cout<<'\n';
        }
    }
	
    if(false == check)
	{
        cout <<"No Records" <<'\n';
    }
}
